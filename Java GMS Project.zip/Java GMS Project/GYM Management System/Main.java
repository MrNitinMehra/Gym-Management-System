package com.gym_management;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.sql.*;
public class Main extends JFrame implements ActionListener,ItemListener,FocusListener
{
    JPanel p;
    JLabel name,l1,l2 ,head,logo1;
    JPasswordField pass;
    JTextField f1;
    JButton btn;
    JCheckBox check;
    String username, password;
    Connection connection;
    PreparedStatement statement;
    ResultSet set;
    public Main()
    {
        p = new JPanel(null);
        logo1 = new JLabel("");
        head = new JLabel("LOGIN");
        name = new JLabel("USERNAME");
        f1 = new JTextField();
        l2 = new JLabel("PASSWORD");
        pass = new JPasswordField();
        btn = new JButton("Log in");
        check = new JCheckBox("Show Password");
        l1 = new JLabel("");
        check.setOpaque(false);

        ImageIcon pic = new ImageIcon(Main.class.getResource("ImagesNitin/gymlogo.png"));
        Image image_1 = pic.getImage().getScaledInstance(340,250,Image.SCALE_SMOOTH);
        ImageIcon im_1 = new ImageIcon(image_1);

        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gym", "root", "12345");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
        logo1.setBounds(90,5,300,200);
        head.setBounds(189,180,100,30);
        name.setBounds(100, 245, 90, 30);
        f1.setBounds(190, 245, 130, 26);
        l2.setBounds(100, 295, 90, 30);
        pass.setBounds(190, 295, 130, 26);
        btn.setBounds(190, 350, 80, 30);
        check.setBounds(280, 350, 140, 30);
        l1.setBounds(190, 210, 190, 30);
        l1.setForeground(Color.RED);
        p.setBackground(Color.decode("#f7ab07"));
        head.setFont(new Font("Arial",Font.BOLD,22));

        BufferedImage f = null;
        try
        {
            f = ImageIO.read(Main.class.getResource("ImagesNitin/gymlogo.png"));
            Image image = f.getScaledInstance(logo1.getWidth(),logo1.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon imageIcon = new ImageIcon(image);
            logo1.setIcon(imageIcon);
        } catch (IOException e) {
            e.printStackTrace();
        }

        p.add(logo1);
        p.add(head);
        p.add(name);
        p.add(f1);
        p.add(pass);
        p.add(l1);
        p.add(l2);
        p.add(btn);
        p.add(check);
        add(p);

        setSize(500,500);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("LOG_In Page");
        setBounds(500,60,500,500);
        setResizable(false);
        btn.addActionListener(this);
        check.addItemListener(this);
        f1.addFocusListener(this);
    }
    public static void main(String[] args)
    {
        Main l = new Main();
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource().equals(btn))
        {
            username= f1.getText();
            password= String.valueOf(pass.getPassword());

        try
        {
            statement = connection.prepareStatement("select * from gym where username=? and password=?");
            statement.setString(1,username);
            statement.setString(2,password);
            set=statement.executeQuery();
            if(set.next())
            {
                Second_Page h = new Second_Page();
                this.dispose();
            }else{
                l1.setVisible(true);
                l1.setText("Invalid Username or Password");
            }
        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        }
    }
    @Override
    public void itemStateChanged(ItemEvent e)
    {
        if (check.isSelected())
        {
            pass.setEchoChar((char)0);
        }else
        {
            pass.setEchoChar('*');
        }
    }
    @Override
    public void focusGained(FocusEvent e)
    {
        if (e.getSource().equals(f1))
        {
            l1.setVisible(false);
        }
    }
    @Override
    public void focusLost(FocusEvent e)
    {
        //Nothing here
     }
}