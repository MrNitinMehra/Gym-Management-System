package com.gym_management;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;
public class Sixth_Page extends JFrame implements ActionListener {
    JPanel p;
    JLabel search;
    JTextField d1;
    JButton btn1, back, show;
    JTable jh;
    JScrollPane spp;
    Connection connection;
    PreparedStatement statement;
    ResultSet set;
    int id;
    Vector<String> col;
    Vector<Vector<String>> v1;
    public Sixth_Page() {
        col = new Vector<>();
        v1 = new Vector<>();
        col.add("ID");
        col.add("Name");
        col.add("Contact");
        col.add("Age");
        col.add("Gender");
        col.add("Address");
        col.add("Email");
        col.add("Amount Pay");
        col.add("Timing");

        p = new JPanel(null);
        search = new JLabel("Search ID");
        d1 = new JTextField();
        btn1 = new JButton("Search");
        back = new JButton("BACK");
        show = new JButton("Show All");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/add_member", "root", "12345");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException ae) {
            ae.printStackTrace();
        }

        search.setBounds(170, 40, 100, 30);
        d1.setBounds(250, 40, 100, 26);
        btn1.setBounds(370, 40, 80, 26);
        show.setBounds(460, 40, 90, 26);
        back.setBounds(280, 400, 80, 30);

        p.setBackground(Color.decode("#f7ab07"));
        p.add(search);
        p.add(d1);
        p.add(btn1);
        p.add(show);
        p.add(back);
        add(p);

        setSize(700, 500);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(500,60,700,500);
        setResizable(false);
        setTitle("Search");

        back.addActionListener(this);
        show.addActionListener(this);
        btn1.addActionListener(this);
    }
    public static void main(String[] args) {
        Sixth_Page f = new Sixth_Page();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btn1)) {
            v1.removeAllElements();
            id = Integer.parseInt(d1.getText());

            try {
                statement = connection.prepareStatement("select * from add_member where id=?");
                statement.setInt(1, id);
                set = statement.executeQuery();

                int i = 1;
                while (set.next()) {
                    Vector<String> v2 = new Vector<>();
                    v2.add(String.valueOf(set.getInt(1)));
                    v2.add(set.getString(2));
                    v2.add(set.getString(3));
                    v2.add(set.getString(4));
                    v2.add(set.getString(5));
                    v2.add(set.getString(6));
                    v2.add(set.getString(7));
                    v2.add(set.getString(8));
                    v2.add(set.getString(9));
                    i++;

                    v1.add(v2);
                    d1.setText("");
                }
                jh = new JTable(v1, col);
                spp = new JScrollPane(jh);
                spp.setBounds(19, 100, 650, 280);
                p.add(spp);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (e.getSource().equals(back)) {
            Second_Page.main(new String[19]);
            dispose();
        }
        if (e.getSource().equals(show)) {

            try {
                statement = connection.prepareStatement("select * from add_member");
                set = statement.executeQuery();
                int i = 1;
                while (set.next()) {
                    Vector<String> v2 = new Vector<>();
                    v2.add(String.valueOf(set.getInt(1)));
                    v2.add(set.getString(2));
                    v2.add(set.getString(3));
                    v2.add(set.getString(4));
                    v2.add(set.getString(5));
                    v2.add(set.getString(6));
                    v2.add(set.getString(7));
                    v2.add(set.getString(8));
                    v2.add(set.getString(9));
                    i++;

                    v1.add(v2);
                    d1.setText("");
                }
                jh = new JTable(v1, col);
                spp = new JScrollPane(jh);
                spp.setBounds(19, 100, 650, 280);
                p.add(spp);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }

        }
    }
}