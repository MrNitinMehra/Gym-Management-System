package com.gym_management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Third_Page extends JFrame implements ActionListener{
    JPanel p;
    JLabel name1,contact1,adds,gender1,birth1,identify,email1,mid1,time;
    JTextField f1,f2,f4,f5,f6;
    JTextArea f3;
    JRadioButton mal;
    JRadioButton fe;
    JComboBox clock;
    ButtonGroup bg;
    JButton Add,back;
    Connection connection;
    PreparedStatement statement;

    int  id ;
    String name,contact,age,gender,address,email,clock1;
    String on[] ={"9:00 Am - 1:00 Pm","3:00 Pm - 9:00 Pm"};

    public Third_Page()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/add_member","root","12345");

        }catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }catch (SQLException ae)
        {
            ae.printStackTrace();
        }

        p = new JPanel(null);
        name1 = new JLabel(" ADD NEW MEMBER");
        mid1= new JLabel("MEMBER ID");
        birth1= new JLabel("AGE");
        contact1= new JLabel("CONTACT");
        adds = new JLabel("ADDRESS");
        gender1 = new JLabel("GENDER");
        time = new JLabel("TIMING");
        mal = new JRadioButton("Male",true);
        fe = new JRadioButton("Female");
        clock = new JComboBox(on);
        bg = new ButtonGroup();
        Add = new JButton("ADD");
        back = new JButton("BACK");
        identify = new JLabel("NAME");
        email1 = new JLabel("EMAIL");
        f1 = new JTextField();
        f2 = new JTextField();
        f3 = new JTextArea();
        f4 = new JTextField();
        f5 = new JTextField();
        f6 = new JTextField();

        name1.setBounds(150,20,250,30);
        mid1.setBounds( 20,90,100,30);
        f1.setBounds( 100,90,100,26);
        identify.setBounds(280,90,100,30);
        f4.setBounds(330,90,100,26);
        contact1.setBounds(260,150,100,30);
        f2.setBounds( 330,150,100,26);
        birth1.setBounds(20,150,100,30);
        f6.setBounds(100,150,100,26);
        gender1.setBounds(20,210,100,30);
        mal.setBounds(100,210,60,28);
        fe.setBounds(170,210,70,28);
        time.setBounds(270,210,120,28);
        clock.setBounds(330,210,120,28);
        adds.setBounds(20,280,100,30);
        f3.setBounds(100,280,150,50);
        email1.setBounds(280,280,100,30);
        f5.setBounds(330,280,100,26);
        //buttons
        Add.setBounds(100,400,100,30);
        back.setBounds(330,400,100,30);
        p.setBackground(Color.decode("#f7ab07"));
        name1.setFont(new Font("Arial",Font.BOLD,19));
        bg.add(mal);
        bg.add(fe);
        p.add(name1);
        p.add(gender1);
        p.add(email1);
        p.add(mid1);
        p.add(contact1);
        p.add(adds);
        p.add(birth1);
        p.add(mal);
        p.add(fe);
        p.add(clock);
        p.add(time);
        p.add(f1);
        p.add(f2);
        p.add(f3);
        p.add(f4);
        p.add(f5);
        p.add(f6);
        p.add(Add);
        p.add(back);
        p.add(identify);
        add(p);
        setSize(500,500);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(500,60,500,500);
        setResizable(false);
        setTitle("Add Member Page ");
        back.addActionListener(this);
        Add.addActionListener(this);
    }
    public static void main(String[] args)
    {
        Third_Page c = new Third_Page();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(Add))
        {
            id = Integer.parseInt(f1.getText());
            name= String.valueOf(f4.getText());
            contact= String.valueOf(f2.getText());
            age= String.valueOf(f6.getText());
            address= String.valueOf(f3.getText());
            email= String.valueOf(f5.getText());
            clock1 = String.valueOf(clock.getSelectedItem());
            if (mal.isSelected())
            {
                gender= String.valueOf(mal.getText());
            }
            else if (fe.isSelected())
            {
                gender= String.valueOf(fe.getText());
            }
            try
            {
                statement= connection.prepareStatement("insert into add_member(id, name, contact, age, gender, address,email,clock) values(?,?,?,?,?,?,?,?)");
                statement.setInt(1,id);
                statement.setString(2,name);
                statement.setString(3,contact);
                statement.setString(4,age);
                statement.setString(5,gender);
                statement.setString(6,address);
                statement.setString(7,email);
                statement.setString(8,clock1);
                statement.executeUpdate();

                JOptionPane.showMessageDialog(Third_Page.this, "Saved");
                f1.setText("");
                f2.setText("");
                f3.setText("");
                f4.setText("");
                f5.setText("");
                f6.setText("");

                if ((mal.isSelected()))
                {
                    mal.setSelected(false);
                }
                else if (fe.isSelected())
                {
                    fe.setSelected(false);
                }
            }
            catch (SQLException throwables)
            {
                throwables.printStackTrace();
            }
        }
        if (e.getSource().equals(back))
        {
           Second_Page.main(new String[2]);
            dispose();
        }

    }
}

