package com.gym_management;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Second_Page extends JFrame implements ActionListener
{
    JPanel p;
    JLabel welcome,logo_1;
    JButton home;
    JButton search;
    JButton add;
    JButton pay;
    JButton log;
    JButton up;

    public Second_Page()
    {
        p=new JPanel(null);
        welcome = new JLabel("WELCOME");
        logo_1 = new JLabel("");
        home= new JButton("Records");
        search= new JButton("Search");
        pay= new JButton("Payment");
        add= new JButton("Add Member");
        up = new JButton("Update");
        log= new JButton("Log out");

        ImageIcon pic = new ImageIcon(Main.class.getResource("ImagesNitin/homelogo.png"));
        Image image_1 = pic.getImage().getScaledInstance(340,250,Image.SCALE_SMOOTH);
        ImageIcon im_1 = new ImageIcon(image_1);

        logo_1.setBounds(100,100,340,250);
        welcome.setBounds(200,40,150,30);
        add.setBounds(20,40,110,30);
        pay.setBounds(20,190,90,30);
        search.setBounds(20,360,100,30);
        up.setBounds(400,40,110,30);
        log.setBounds(405,360,100,30);
        home.setBounds(415,190,90,30);

        p.setBackground(Color.decode("#f7ab07"));
        welcome.setFont(new Font("Arial",Font.BOLD,25));

        BufferedImage f = null;
        try
        {
            f = ImageIO.read(Main.class.getResource("ImagesNitin/homelogo.png"));
            Image image = f.getScaledInstance(logo_1.getWidth(),logo_1.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon imageIcon = new ImageIcon(image);
            logo_1.setIcon(imageIcon);
        } catch (IOException e) {
            e.printStackTrace();
        }

        p.add(welcome);
        p.add(logo_1);
        p.add(home);
        p.add(search);
        p.add(pay);
        p.add(add);
        p.add(log);
        p.add(up);
        add(p);

        setSize(550,470);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Admin_Page");
        setBounds(500,60,550,500);
        setResizable(false);

        home.addActionListener(this);
        search.addActionListener(this);
        pay.addActionListener(this);
        add.addActionListener(this);
        log.addActionListener(this);
        up.addActionListener(this);
    }
    public static void main(String[] args)
    {
        Second_Page b = new Second_Page();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource().equals(add))
        {
            Third_Page.main(new String[1]);
            dispose();
        }
        else if (e.getSource().equals(up))
        {
            Fourth_Page.main(new String[2]);
            dispose();
        }
        else if (e.getSource().equals(pay))
        {
            Fifth_Page.main(new String[3]);
            dispose();
        }
        else if (e.getSource().equals(log))
        {
            JOptionPane.showMessageDialog(Second_Page.this, "Log out");
            Main.main(new String[4]);
            dispose();
        }
        else if (e.getSource().equals(search))
        {
            Sixth_Page.main(new String[5]);
            dispose();
        }
        else if (e.getSource().equals(home))
        {
            Seventh_Page.main(new String[9]);
            dispose();
        }
    }
}
