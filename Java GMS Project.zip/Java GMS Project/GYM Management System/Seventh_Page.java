package com.gym_management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class Seventh_Page extends JFrame implements ActionListener
{
    JPanel p, p1;
    JLabel l1;
    JTextField f1;
    JButton bt1,bt2;
    JScrollPane sp;
    JTable tb1;
    Vector<String> col;
    Vector<Vector<String>> v1;
    int id;
    Connection connection;
    PreparedStatement statement;
    ResultSet set;

    public Seventh_Page() {
        col = new Vector<>();
        v1 = new Vector<>();

        col.add("Id");
        col.add("Name");
        col.add("Date");
        col.add("Time");
        col.add("Amount Pay");

        p = new JPanel(null);
        p1 = new JPanel(null);
        l1 = new JLabel("Member ID");
        f1 = new JTextField();
        bt1 = new JButton("Search");
        bt2 = new JButton("Back");

        p1.setBounds(20, 80, 450, 280);
        l1.setBounds(100, 40, 150, 30);
        f1.setBounds(170, 40, 100, 26);
        bt1.setBounds(285, 40, 90, 25);
        bt2.setBounds(195, 370, 90, 25);
        p.setBackground(Color.decode("#f7ab07"));
        p1.setBackground(Color.decode("#f7ab07"));
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/add_member", "root", "12345");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException ae)
        {
            ae.printStackTrace();
        }

        p.add(p1);
        p.add(l1);
        p.add(f1);
        p.add(bt1);
        p.add(bt2);
        add(p);

        p1.setVisible(false);
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(500,60,500,500);
        setResizable(false);
        setVisible(true);
        setTitle("Payment Record");
        bt1.addActionListener(this);
        bt2.addActionListener(this);
    }
    public static void main(String[] args)
    {
        Seventh_Page se = new Seventh_Page();
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource().equals(bt1))
        {
            p1.setVisible(true);
            id = Integer.parseInt(f1.getText());
            v1.removeAllElements();
            try {
                statement = connection.prepareStatement("select * from record where id=?");
                statement.setInt(1, id);
                set = statement.executeQuery();
                int i = 1;
                while (set.next()) {
                    Vector<String> v2 = new Vector<>();
                    v2.add(String.valueOf(set.getInt(1)));
                    v2.add(set.getString(2));
                    v2.add(set.getString(3));
                    v2.add(set.getString(4));
                    v2.add(set.getString(5));

                    i++;
                    v1.add(v2);
                }
                tb1 = new JTable(v1, col);
                sp = new JScrollPane(tb1);
                sp.setBounds(15, 30, 420, 250);
                p1.add(sp);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (e.getSource().equals(bt2))
        {
            Second_Page.main(new String[5]);
            dispose();
        }
    }
}