package com.gym_management;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Fourth_Page extends JFrame implements ActionListener
{
    JPanel p;
    JLabel l,l1,l2,l3,l4,l5,l6,l7,l8;
    JTextField f1,f2,f3,f4,f5,f7;
    JTextArea f6;
    JButton save,rest,back,search1;
    JRadioButton male,female;
    ButtonGroup bg;
    int id;
    Connection connection;
    PreparedStatement statement;
    ResultSet set;
    String name,contact,email,address,age,gender,payment;

    public Fourth_Page()
    {
        p = new JPanel(null);
        l = new JLabel("UPDATE DELETE MEMBER");
        l1 = new JLabel("Member ID");
        l2 = new JLabel("Name");
        l3 = new JLabel("Email");
        l4 = new JLabel("Contact");
        l5 = new JLabel("Age");
        l6 = new JLabel("Address");
        l7 = new JLabel("Gender");
        l8 = new JLabel("Amount Paid");
        f1 = new JTextField();
        f2 = new JTextField();
        f3 = new JTextField();
        f4 = new JTextField();
        f5 = new JTextField();
        f6 = new JTextArea();
        f7 = new JTextField();
        bg = new ButtonGroup();
        save = new JButton("Save");
        rest = new JButton("Delete");
        back = new JButton("BACK");
        search1 = new JButton("Search");
        male = new JRadioButton("Male");
        female = new JRadioButton("Female");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/add_member","root","12345");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException ae)
        {
            ae.printStackTrace();
        }

        l.setBounds(135,20,270,30);
        l1.setBounds(20,80,100,30);
        l2.setBounds(300,80,100,30);
        l3.setBounds(300,130,100,30);
        l4.setBounds(300,190,100,30);
        l5.setBounds(300,250,100,30);
        l6.setBounds(20,250,100,30);
        l7.setBounds(20,190,100,30);
        l8.setBounds(19,130,100,30);

        f1.setBounds(100,80,100,26);
        f2.setBounds(350,80,100,26);
        f3.setBounds(350,130,100,26);
        f4.setBounds(350,190,100,26);
        f5.setBounds(350,250,100,26);
        f6.setBounds(100,250,140,50);
        f7.setBounds(100,130,100,26);

        male.setBounds(100,190,60,26);
        female.setBounds(170,190,70,26);
        search1.setBounds(210,80,75,25);
        save.setBounds(60,390,100,30);
        rest.setBounds(180,390,100,30);
        back.setBounds(300,390,100,30);
        l.setFont(new Font("Arial",Font.BOLD,19));

        p.setBackground(Color.decode("#f7ab07"));
        bg.add(male);
        bg.add(female);
//        rest.setVisible(false);

        p.add(l);
        p.add(l1);
        p.add(l2);
        p.add(l3);
        p.add(l4);
        p.add(l5);
        p.add(l6);
        p.add(l7);
        p.add(l8);
        p.add(f1);
        p.add(f2);
        p.add(f3);
        p.add(f4);
        p.add(f5);
        p.add(f6);
        p.add(f7);
        p.add(male);
        p.add(female);
        p.add(save);
        p.add(rest);
        p.add(search1);
        p.add(back);

        add(p);
        setSize(500,500);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(500,60,500,500);
        setResizable(false);
        setTitle("Update&Delete");

        save.addActionListener(this);
        rest.addActionListener(this);
        search1.addActionListener(this);
        back.addActionListener(this);
    }
    public static void main(String[] args)
    {
        Fourth_Page foc = new Fourth_Page();
    }
    @Override
    public void actionPerformed(ActionEvent e)
    {    // UPDATE QUERY
        if (e.getSource().equals(search1)){

            id=Integer.parseInt(f1.getText());
//            rest.setVisible(true);
            try {
                statement=connection.prepareStatement("select * from add_member where id=? ");
                statement.setInt(1,id);
                set=statement.executeQuery();
                if(set.next())
                {
                    name= set.getString(2);
                    contact=set.getString(3);
                    age=set.getString(4);
                    gender=set.getString(5);
                    address=set.getString(6);
                    email=set.getString(7);
                    payment=set.getString(8);

                    f2.setText(name);
                    f3.setText(email);
                    f4.setText(contact);
                    f5.setText(age);
                    f6.setText(address);
                    f7.setText(payment);

                    if(gender.equalsIgnoreCase("Male"))
                    {
                        male.setSelected(true);
                    }
                    else
                    {
                        female.setSelected(true);
                    }
                }
            }
            catch (SQLException ex)
            {
                ex.printStackTrace();
            }
        }
        //end
        if (e.getSource().equals(save))
        {
            id = Integer.parseInt(f1.getText());
            name=f2.getText();
            contact= f4.getText();
            age= f5.getText();
            address= f6.getText();
            email= f3.getText();
            payment= f7.getText();

            if (male.isSelected())
            {
                gender= String.valueOf(male.getText());
            }
            else if (female.isSelected())
            {
                gender= String.valueOf(female.getText());
            }
            try
            {
                statement= connection.prepareStatement("update add_member set name=?,contact=?,age=?,address=?,email=?,gender=?,payment=? where id=?");
                statement.setString(1,name);
                statement.setString(2,contact);
                statement.setString(3,age);
                statement.setString(4,address);
                statement.setString(5,email);
                statement.setString(6,gender);
                statement.setString(7,payment);
                statement.setInt(8, id);
                statement.executeUpdate();

                f1.setText("");
                f2.setText("");
                f3.setText("");
                f4.setText("");
                f5.setText("");
                f6.setText("");
                f7.setText("");

                if ((male.isSelected()))
                {
                    male.setSelected(false);
                }
                else if (female.isSelected())
                {
                    female.setSelected(false);
                }
            }
            catch (SQLException throwables)
            {
                throwables.printStackTrace();
            }
        }
// Delete Query
        if (e.getSource().equals(rest))
        {
            id = Integer.parseInt(f1.getText());

            try {
                statement=connection.prepareStatement("Delete from add_member where id=?");
                statement.setInt(1, id);
                int i = statement.executeUpdate();

                if(i>0)
                {
                    JOptionPane.showMessageDialog(Fourth_Page.this, "Record Deleted");
                    f1.setText("");
                    f2.setText("");
                    f3.setText("");
                    f4.setText("");
                    f5.setText("");
                    f6.setText("");
                    f7.setText("");
                }
                else
                {
                    JOptionPane.showMessageDialog(Fourth_Page.this, "Error Deleting Record.. Try again");
                }
                try{
                    statement=connection.prepareStatement("Delete from record where id=?");
                    statement.setInt(1, id);
                    statement.executeUpdate();
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            } catch (SQLException ex)
            {
                ex.printStackTrace();
            }
            // BACK Button
        }
        if (e.getSource().equals(back))
        {
            Second_Page.main(new String[9]);
            dispose();
        }
    }
}
