package com.gym_management;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Month;
import java.util.Calendar;
import java.sql.*;
import java.util.Date;

public class Fifth_Page extends JFrame implements ActionListener {
    JPanel p;
    JLabel me, na, mob, em, pay,head;
    JTextField f1, f2, f3, f4, f5;
    JButton se, sa, reset, back;
    Calendar c1;
    Connection connection;
    PreparedStatement statement;
    ResultSet set;
    int id;
    int Date,Month,Year;
    int Hours, MIN;
    String name, contact, email,payment,date,time;

    public Fifth_Page()
    {
        p = new JPanel(null);
        me = new JLabel("Member Id");
        head = new JLabel("Payment Details");
        na = new JLabel("Name");
        mob = new JLabel("Phone Number");
        em = new JLabel("Email");
        pay = new JLabel("Amount to Pay");
        se = new JButton("Search");
        sa = new JButton("Save");
        back = new JButton("BACK");
        f1 = new JTextField();
        f2 = new JTextField();
        f3 = new JTextField();
        f4 = new JTextField();
        f5 = new JTextField();

        c1 = Calendar.getInstance();
        Date = c1.get(Calendar.DATE);
        Month  = c1.get(Calendar.MONTH);
        Year = c1.get(Calendar.YEAR);
        Hours = c1.get(Calendar.HOUR);
        MIN = c1.get(Calendar.MINUTE);

        Month = Month+1;

        date=Date+"/"+Month+"/"+Year;
        time = Hours+":"+MIN;

        head.setBounds(150,20,250,30);
        me.setBounds(20, 80, 100, 20);
        na.setBounds(20, 130, 100, 20);
        mob.setBounds(20, 170, 100, 20);
        em.setBounds(20, 210, 100, 20);
        pay.setBounds(20, 260, 100, 20);

        f1.setBounds(130, 80, 100, 20);
        f2.setBounds(130, 130, 100, 20);
        f3.setBounds(130, 170, 100, 20);
        f4.setBounds(130, 210, 100, 20);
        f5.setBounds(130, 260, 100, 20);

        sa.setBounds(30, 350, 90, 30);
        se.setBounds(250, 80, 80, 20);
        back.setBounds(230, 350, 90, 30);
        p.setBackground(Color.decode("#f7ab07"));
        head.setFont(new Font("Arial",Font.BOLD,19));


        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/add_member", "root", "12345");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException ae)
        {
            ae.printStackTrace();
        }

        p.add(me);
        p.add(na);
        p.add(mob);
        p.add(em);
        p.add(pay);
        p.add(se);
        p.add(sa);
        p.add(back);
        p.add(head);
        p.add(f1);
        p.add(f2);
        p.add(f3);
        p.add(f4);
        p.add(f5);
        add(p);
        setSize(430, 470);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(500,60,430,470);
        setResizable(false);
        setTitle("Payment");
        se.addActionListener(this);
        back.addActionListener(this);
        sa.addActionListener(this);
    }
    public static void main(String[] args) {
        Fifth_Page e = new Fifth_Page();
        Calendar ac = Calendar.getInstance();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(se))
        {
            id = Integer.parseInt(f1.getText());

            try {
                statement = connection.prepareStatement("select * from add_member where id=? ");
                statement.setInt(1, id);
                set = statement.executeQuery();

                if (set.next())
                {
                    name = set.getString(2);
                    contact = set.getString(3);
                    email = set.getString(7);

                    f2.setText(name);
                    f3.setText(contact);
                    f4.setText(email);
                }
            }
            catch (SQLException ex)
            {
                ex.printStackTrace();
            }
        }
        if (e.getSource().equals(sa))
        {
            id  = Integer.parseInt(f1.getText());
            payment= f5.getText();

            try {
                statement = connection.prepareStatement("update add_member set payment=? where id=?");
                statement.setString(1,payment);
                statement.setInt(2,id);
                statement.executeUpdate();
                JOptionPane.showMessageDialog(Fifth_Page.this, "Payment Saved");
                f1.setText("");
                f2.setText("");
                f3.setText("");
                f4.setText("");
                f5.setText("");
            }
            catch (SQLException throwables)
            {
                throwables.printStackTrace();
            }
            try{
                statement = connection.prepareStatement("insert into record(id,name,date,time,payment) values(?,?,?,?,?)");
                statement.setInt(1,id);
                statement.setString(2,name);
                statement.setString(3,date);
                statement.setString(4, time);
                statement.setString(5, payment);
                statement.executeUpdate();
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }
        if (e.getSource().equals(back))
        {
            Second_Page.main(new String[1]);
            dispose();
        }
    }
}

